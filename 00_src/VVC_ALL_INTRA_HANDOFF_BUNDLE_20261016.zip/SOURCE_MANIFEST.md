# Source manifest (SHA-256)

Name | Bytes | SHA-256
--- | ---: | ---
`RECON_DUAL_BANK_RTL_INTEGRATION.zip` | 30466 | `18ee3d7ec53179ee197a85096a97145b36bfd5e78c0aff2bdcbf9311eb90b048`
`RECON_SUBSYSTEM(2).zip` | 22852 | `fb5c928db69bd2e982583bf871c0d35bff3edc34495ccfab6d1da5e472067b70`
`CTU_INPUT_ENGINE(4).zip` | 19552 | `43f1434492ceabf642dfaf70d6b9b30a88222c09111fb0fe35d680ea8649d8a8`
`PARTITION_ENGINE(10).zip` | 47324 | `3f5e8652dbafe3cde609ba4a5b4766a6d4bc132a77c04b6094c5b89ec1e09243`
`INTRA_PREDICTION_ENGINE(10).zip` | 106603 | `4fd20dc84fe5fdf2d695898cb280081190208a5028d9f2d8c29b5c99fa04dea5`
`TRANS_QUANT(2).zip` | 62411 | `9daba8180ec7da55339bd02c402770cabb8324cb25e35265910b131cfe4b541a`
`INV_TRANS_QUANT.zip` | 58891 | `598fab989582096a44ae619229c3dfc74fb2a71217e8659b333cc5a8a0b9892d`
`SystemVerilog_Coding_Style_and_Design_Guideline_Final(20261016-133403).pdf` | 185013 | `743bd3bedfb1f915cb7ea50b927a12b95ddf7f15fc7d9e1e7128492c3169d05a`

Note: the external ITU VVC reference PDF is not included in this portable bundle, because it is much larger. Attach it separately if normative details are needed.
