# H.266/VVC All-Intra Encoder — DESIGN HANDOFF

**Snapshot:** 2026-10-16  |  **Ngôn ngữ thiết kế:** synthesizable SystemVerilog  |  **Mục đích:** chuyển sang chat mới mà không mất quyết định kiến trúc, trạng thái source/verification và các blocker.

> **ĐỌC TRƯỚC KHI SỬA RTL:** Tài liệu này tổng hợp kiến trúc đã thảo luận và đối chiếu những source hiện có trong bundle. Nó **không** chứng nhận bitstream phù hợp chuẩn VVC, không chứng nhận closure 200 MHz hoặc 4K30, và không biến những testbench **chưa chạy** thành PASS. Nếu có xung đột giữa lời giải thích cũ và RTL mới nhất, mở RTL mới nhất để xác nhận chính xác interface.

## A. Source of truth và tài nguyên dự án

### A.1. Bản hiện hành ưu tiên

| Artifact | Vai trò / mức ưu tiên |
|---|---|
| `RECON_DUAL_BANK_RTL_INTEGRATION.zip` | **Baseline MỚI NHẤT của Recon Subsystem**. Có `rtl/RECON_LOCAL_RAM_BANK_CTRL.sv`, `rtl/RECON_SUBSYSTEM_TOP.sv` đã sửa, 11 module RTL còn lại, 1 TB và 2 script. Dùng thay cho Recon Top cũ. |
| `RECON_SUBSYSTEM(2).zip` | Source Recon trước khi sửa thành dual-bank. Tham khảo đối chiếu, **không dùng lẫn `RECON_SUBSYSTEM_TOP.sv` cũ** với source mới. |
| `CTU_INPUT_ENGINE(4).zip` | CTU input/fetch/AXI/4 original CTU buffers. |
| `PARTITION_ENGINE(10).zip` | QT/BT/TT partition, feature banks, leaf FIFO, syntax FIFO. Chứa `ENCODER_TU_SCHEDULER.sv`. |
| `INTRA_PREDICTION_ENGINE(10).zip` | Intra Prediction, reference path, modes, syntax support. |
| `TRANS_QUANT(2).zip` | Forward transform, quantization RTL hiện có. |
| `INV_TRANS_QUANT.zip` | Inverse quantization và inverse transform RTL hiện có. |
| `SystemVerilog_Coding_Style_and_Design_Guideline_Final(20261016-133403).pdf` | **Coding style mới nhất** — dùng cho mọi RTL mới/sửa. |
| `T-REC-H.266-202601-I!!PDF-E(4).pdf` | Tài liệu tiêu chuẩn VVC do user cung cấp (đưa vào chat mới khi cần kiểm tra conformance). |

### A.2. Supplemental RTL từng tạo riêng

- `residual_generator/RESIDUAL_GENERATOR.sv` và `residual_generator/INTEGRATION_NOTES.md`: original prefetch của Leaf CU và residual generation; phiên bản hiện có trong bundle.
- `prediction_stream_fork/PREDICTION_STREAM_FORK.sv`: phân nhánh Prediction stream tới Residual Generator và Final Prediction Buffer, chống duplicate/lost beats khi stall.
- `reconstruction_engine_fixed/RECONSTRUCTION_ENGINE.sv`: bản Recon Engine từng sửa; **cần đối chiếu** với `rtl/RECONSTRUCTION_ENGINE.sv` trong Recon dual-bank ZIP để tránh ghi đè bản khác nhau.
- `CTU_ORIGINAL_READ_MUX.sv` và `FINAL_PREDICTION_BUFFER.sv` đã từng được thiết kế trong cuộc trò chuyện cũ, nhưng **không tìm thấy file độc lập của hai module này trong bản bundle được kiểm kê hiện tại**: yêu cầu user cung cấp source trước khi sửa/tích hợp chúng.
- `CTU_RECON_EXPORT`: **ĐÃ BỎ KHỎI DATAPATH CHÍNH** theo quyết định mới; không tiếp tục nối module Export cũ vào Bank Controller.

### A.3. Quy tắc versioning

Giữ `RECON_DUAL_BANK_RTL_INTEGRATION.zip` làm Recon reference. Các tên trùng nhau trong `RECON_SUBSYSTEM.zip`, `RECON_SUBSYSTEM_INTEGRATION.zip`, `RECON_SUBSYSTEM(2).zip` và gói Export là phiên bản lịch sử. Không lấy một port definition từ bản cũ rồi trộn với bản mới.

## B. Các tham số đã chốt

| Chủ đề | Giá trị / ghi chú |
|---|---|
| Mục tiêu | VVC/H.266 **All-Intra**, FPGA; mục tiêu thiết kế video 3840×2160 @ 30fps. |
| Clock mục tiêu | 200 MHz (**chưa đạt timing signoff**). |
| Video | YUV 4:2:0, bit depth 10. |
| CTU | 128×128 (luma), chroma 64×64 trong CTU đầy đủ. |
| CTU/frame 4K | `ceil(3840/128) × ceil(2160/128) = 30 × 17 = 510`; CTU hàng cuối valid height 112 luma. |
| Partition | Single-Tree luma; QT/BT/TT; Leaf CU luma tối đa 32×32, baseline Leaf 8/16/32 tùy split. |
| Datapath | 4 samples/cycle. Trong Recon/Filter RAM: 4×16-bit = 64 bit/word, 10 bit có nghĩa mỗi sample. |
| CTU Original Input | `CTU_INPUT_ENGINE` AXI read 128 bit/beat, CTU buffer pool mặc định 4 buffers. |
| CU/TU baseline | Một Leaf CU active ở đường Intra-Recon; theo thiết kế baseline một TU job in-flight trên T/Q-Reconstruction, xử lý component jobs Y→Cb→Cr. |
| Recon RAM | **Hai bank**, mỗi bank 48 KiB cho CTU YUV420 đầy đủ; ownership độc lập. |
| In-loop Input Buffer | **Một buffer** đủ CTU YUV420 48 KiB baseline; chưa có RTL Prefetch/Input Buffer đã xác nhận. Cân nhắc ping-pong sau khi đo latency. |
| FPGA SRAM | 2 MiB là **ngân sách do user nêu để ước tính**, chưa phải kết quả utilization/synthesis. |

**Dung lượng:** 1 CTU = 16,384 Y + 4,096 Cb + 4,096 Cr = 24,576 samples. `24,576 × 16 / 8 = 49,152 bytes = 48 KiB`; 2 Recon banks + 1 In-loop Input Buffer = 144 KiB = 7.03125% của 2 MiB *chỉ xét bit capacity*. Không tính RAM H/V, cross-CTU, Original, feature, transform, filter intermediate, banking/fragmentation, port replication.

**Throughput reference:** 510 CTU/frame × 30 fps = 15,300 CTU/s. 200 MHz / 15,300 ≈ **13,072 cycles/CTU trung bình**. Một CTU 128×128 YUV420 gồm 6,144 words ×64-bit; prefetch liên tục 1 word/cycle có cận dưới **6,144 cycles/CTU** (+ latency/overheads). Đây không phải benchmark full encoder.

## C. Logic tổng thể — 12 stages

```text
HOST PC (Raw YUV420) → PCIe DMA → DDR4
  1  CTU_INPUT_ENGINE: AXI read, original CTU buffer pool, CTU descriptor
  2  PARTITION_ENGINE: luma feature extraction → QT/BT/TT → Leaf FIFO
  3  RESIDUAL_GENERATOR original prefetch: cache Original Y/Cb/Cr cho Leaf
  4  INTRA_PREDICTION_ENGINE: reference fetch / mode decision / final pred
  5  ENCODER_TU_SCHEDULER + PREDICTION_STREAM_FORK
           ├─ Final Prediction Buffer (chờ Reconstruction)
           └─ Residual = Original - Prediction
  6  Forward T/Q: Residual → coefficients → quantized coefficients
           ├─ Syntax/coeff path → (future) CABAC → bitstream
           └─ Inverse path
  7  Inverse Q + Inverse Transform + RECONSTRUCTION_ENGINE
  8  RECON_SUBSYSTEM_TOP: RECON_REF_STORE_WRITER, availability, H/V,
     cross-CTU references, CU commit, 2-bank Recon Local RAM
           ├─ UNFILTERED H/V + cross-CTU → feedback Intra NEXT CU
           └─ Completed CTU Recon bank → In-loop Prefetch handoff
  9  IN_LOOP_PREFETCH_CONTROLLER (MỚI, CHƯA TRIỂN KHAI): raster addr Y/Cb/Cr
  10 IN_LOOP_INPUT_BUFFER (MỚI, CHƯA TRIỂN KHAI): 1 CTU YUV420, 48 KiB
  11 DBF → SAO → ALF (separate intermediate / halo stores)
  12 Filtered frame writeback → DDR4 → Host
```

**Song song:** Stage 1 có thể fetch ahead nếu Original buffer còn; stage 3→8 chạy lặp mỗi Leaf và có thể overlap theo handshake; Stage 9 của CTU N−1 được overlap với Stage 3→8 của CTU N nhờ **hai Recon banks**. Stage 11 có thể tiếp tục sau khi Stage 9 đã giải phóng Recon bank. **Không** yêu cầu Leaf CU chờ In-loop Filters.

**Original CTU RAM sharing:** `CTU_ORIGINAL_READ_MUX` ownership thứ tự Partition → Residual Original Prefetch → Intra original read. Không đổi owner khi synchronous RAM response còn outstanding. `PARTITION.O_FEATURE_READY` báo hoàn tất dùng RAM cho feature extraction; **không nhất thiết cần chờ `PARTITION.O_DONE`** nếu done còn phụ thuộc drain Leaf FIFO. Leaf Context phải giữ geometry/metadata ổn định trong Prefetch và Intra.

**Partition Leaf encoding:** trong `O_LEAF_NODE_DATA[63:0]`, `[52:48] = X_UNIT`, `[47:43] = Y_UNIT`, `[42:40] = width size code`, `[39:37] = height size code`, `[36:29] = valid width`, `[28:21] = valid height`. Đơn vị tọa độ = 4 luma pixels; size = `4 << code`, trong baseline code 1→8, 2→16, 3→32. Xác nhận lại với source trước khi dùng trong module mới.

**Số học Reconstruction:** `Recon = clip10(Prediction + InverseResidual)`; đọc Final Prediction Buffer đúng metadata, nhận four samples/beat. Intra lấy reconstructed **unfiltered** reference từ H_EDGE/V_EDGE/ABOVE_LINE/LEFT_BOUNDARY/ABOVE_LEFT_CORNER và Availability, **KHÔNG đọc `CTU_RECON_LOCAL_RAM`**. Với chroma, Intra/Scheduler đã cấp tọa độ theo component; Reconstruction **không halve thêm lần nữa**.

**Filtering:** DBF đọc **unfiltered reconstructed CTU đã được copy vào In-loop Input Buffer**, SAO đọc output DBF, ALF đọc output SAO. Halo/line buffers cross-CTU riêng; không tái sử dụng mù quáng H/V reference RAM của Intra. Syntax/QP/CU/TU boundary và filter parameters cần đồng bộ theo CTU/boundary.

## D. Scheduling: 3 miền độc lập

### D.1. Miền A — Leaf CU Encoding / Reference Feedback

1. Global FSM nhận Leaf descriptor, giữ Leaf Context; Residual prefetch đủ Original Y/Cb/Cr.
2. Intra Mode Decision và Final Prediction; TU Scheduler sinh các component jobs / TU IDs; Fork fan-out đến Residual và Prediction Buffer.
3. T/Q → inverse Q/T → Reconstruction → Recon Writer cập nhật Local RAM + H/V Edge/Availability.
4. `INTRA_PREDICTION_ENGINE.O_CU_REF_COMMIT_REQ` yêu cầu xác nhận; `RECON_SUBSYSTEM_TOP.O_CU_REF_COMMIT_DONE` trả về khi Y/Cb/Cr và delayed availability updates đã an toàn.
5. Sau `INTRA.O_CU_DONE`, các TU/resources đã release và handshake Leaf hợp lệ → **Next Leaf CU được phép bắt đầu**.

**KHÔNG dùng một `O_TU_DONE` đơn lẻ thay cho CU commit. KHÔNG chờ DBF/SAO/ALF để chuyển Leaf.** `RECON_REF_STORE_WRITER.O_TU_REF_RELEASE` không tương đương `CU_REF_COMMIT_DONE`.

### D.2. Miền B — CTU Completion / Dual Recon RAM Ownership

- **Last Leaf commit không tự sinh CTU Finish**: Global FSM phải xác nhận Leaf cuối đã consumed/committed, T/Q-Recon không còn beat outstanding, last writer đã ghi xong, resources/metadata nhất quán.
- Global FSM thực hiện `RECON_SUBSYSTEM_TOP.I_CTU_FINISH_VALID && O_CTU_FINISH_READY` → `w_ctu_finish` của Recon Top → Bank đang `WRITING` chuyển `READY`, descriptor được enqueue.
- `RECON_LOCAL_RAM_BANK_CTRL` cấp một FREE bank tại CTU Start; trạng thái mỗi bank: `ST_FREE → ST_WRITING → ST_READY → ST_PREFETCHING → ST_FREE`.
- Descriptor FIFO sâu 2 giữ CTU finish order; một Prefetch consumer tại một thời điểm; có thể Prefetch CTU N−1 từ Bank A và Reconstruction CTU N vào Bank B.
- Prefetch Controller phát full raster requests, ghi Input Buffer và **chỉ phát release sau khi mọi response đã về, mọi write input buffer đã được accept, và halo/dependencies dùng nguồn Recon RAM đã được lưu an toàn**.
- Bank Controller xác minh Bank ID + CTU ID + Frame ID, không có request/response đang chờ trước khi nhận release. `I_CLEAR_ERROR` là **global abort**, không phải retry per-bank.
- Recon Top vẫn sử dụng cùng một tập H/V/Cross-CTU reference trong baseline; bảo đảm CTU lifecycle của Intra không bị gộp với Prefetch ownership.

### D.3. Miền C — In-loop Filtering / Output

- Prefetch bắt đầu khi nhận descriptor bank READY và `IN_LOOP_INPUT_BUFFER` free/ready.
- In-loop Input Buffer giữ CTU sau Prefetch; `O_RECON_RAM_RELEASE` giải phóng **chỉ Recon Bank**, không phải In-loop Input Buffer.
- `INPUT_BUFFER_RELEASE` xảy ra khi không còn filter/boundary consumer nào cần unfiltered CTU trong buffer, **không nhất thiết đợi ALF_DONE** nếu DBF/halo đã tạo independent storage.
- `CTU_FILTER_DONE` xảy ra sau DBF/SAO/ALF cho CTU; `FRAME_WRITE_DONE` chỉ sau filtered data writeback hoàn tất. Các sự kiện riêng biệt, chưa phải các port đã triển khai đầy đủ.

### D.4. Điều kiện chuyển CTU và vòng đời tài nguyên

`NEXT_CTU_RECON_ALLOW` = có FREE Recon bank + Intra cross-CTU references/availability được chuẩn bị + Original CTU descriptor sẵn sàng + current CTU has legally finished + required CU/TU resources free.

**Không cần chờ CTU_FILTER_DONE** để bắt đầu CTU tiếp theo nếu bank khác FREE và cross-CTU refs hợp lệ. Nếu cả hai Recon banks bận, stall CTU Start đến khi một bank được release. Một Input Buffer duy nhất vẫn có thể gây backpressure Prefetch (đo T_E/T_P/T_F trước khi tăng số buffers).

## E. Interface chính của Dual Recon RAM (đã có RTL, kiểm tra lại file để lấy tất cả width)

**Module mới:** `RECON_LOCAL_RAM_BANK_CTRL.sv` (instantiates 2 unchanged `CTU_RECON_LOCAL_RAM.sv`). **Tích hợp trong:** `RECON_SUBSYSTEM_TOP.sv`.

### E.1. CTU allocate / finish

- `I_CTU_ALLOC_VALID`, `O_CTU_ALLOC_READY`.
- `I_CTU_ID[8:0]`, `I_FRAME_ID[7:0]`, `I_CTU_X_ORIGIN[12:0]`, `I_CTU_Y_ORIGIN[12:0]`, `I_CTU_VALID_WIDTH[7:0]`, `I_CTU_VALID_HEIGHT[7:0]`.
- `I_CTU_RECON_FINISH` được drive từ **handshake `w_ctu_finish`**, không phải raw `I_CTU_FINISH_VALID`.
- `O_WR_ACTIVE`, `O_ACTIVE_WRITE_BANK_ID`; mỗi bank state 2-bit output.

### E.2. Write path

`I_WR_EN`, `I_WR_COMPONENT_ID[1:0]`, `I_WR_ADDR[11:0]`, `I_WR_DATA[63:0]`, `I_WR_SAMPLE_EN[3:0]` nhận từ Writer; Bank Controller **chỉ chọn write bank**, không tính pixel address. Local RAM component address: Y word `y*32 + (x>>2)`; Cb/Cr word `y*16 + (x>>2)` trong component coordinates.

### E.3. Prefetch descriptor / memory request / release

- `O_PREFETCH_DESC_VALID`, `I_PREFETCH_DESC_READY` và stable payload `{O_PREFETCH_BANK_ID, O_PREFETCH_CTU_ID, O_PREFETCH_FRAME_ID, O_PREFETCH_CTU_X_ORIGIN, O_PREFETCH_CTU_Y_ORIGIN, O_PREFETCH_VALID_WIDTH, O_PREFETCH_VALID_HEIGHT}`.
- `I_PREFETCH_RD_EN`, `I_PREFETCH_RD_COMPONENT_ID[1:0]`, `I_PREFETCH_RD_ADDR[11:0]`; response `O_PREFETCH_RD_VALID`, `O_PREFETCH_RD_DATA[63:0]`, `O_PREFETCH_RD_BANK_ID`.
- **Không có ready per-read.** RAM response synchronous registered 1-cycle; Prefetch phải ngừng issue request nếu không đủ capacity nhận response; read response của bank cũ không được chọn bằng bank ID đã đổi.
- `I_PREFETCH_RELEASE_VALID`, `O_PREFETCH_RELEASE_READY`, `I_PREFETCH_RELEASE_BANK_ID`, `I_PREFETCH_RELEASE_CTU_ID[8:0]`, `I_PREFETCH_RELEASE_FRAME_ID[7:0]`.
- `I_CLEAR_ERROR` flush all ownership/queue/response state; `I_PICTURE_START` trong Recon Top **không reset Recon Banks**. Frame ID chống nhầm epoch.

**Quyết định ĐÓNG BĂNG:** BANK CONTROLLER **KHÔNG có** raster address counter, không có prefetch word count = 6144, không sinh logic Y→Cb→Cr. Việc đó thuộc `IN_LOOP_PREFETCH_CONTROLLER` (mới).

### E.4. Input Buffer memory organization chưa hiện thực

Baseline đề xuất một 48 KiB memory cho YUV420: Y 4096×64, Cb 1024×64, Cr 1024×64. Thứ tự prefetch Y→Cb→Cr, raster theo valid width/height và component geometry (chroma half-size cho 4:2:0, nếu boundary odd dimensions cần định nghĩa rounding/lane masks). Nếu runtime hỗ trợ max 4 valid samples per beat, xem xét policy với partial words. Chỉ release Recon Bank sau khi data/halo giữ đủ; data đã copy cần được giữ nguyên cho đúng CTU/Frame ID cho tới Input Buffer release.

## F. Coding style BẮT BUỘC (PDF ngày 2026-10-16)

- Mỗi file một module và filename trùng module; `endmodule: MODULE_NAME`.
- Header mô tả bằng tiếng Anh, `timescale 1ns/1ps`.
- Uppercase module/parameter/port; `PARA_` parameter/localparam; ports `I_` / `O_`; internal `r_` registered, `w_` combinational, snake_case.
- 2 spaces indent; comments `//` tiếng Anh; signal declarations đầu body.
- RTL chỉ dùng `assign`, `always_comb`, `always_ff`; reset theo kiến trúc active-low (`I_RESETN` cho Recon); một reg/one sequential driver; nonblocking `<=` trong `always_ff`; không clock gating bằng phép AND thủ công.
- FSM control theo 3-process: state FF, next-state combinational, output combinational; enum `ST_*`, `r_current_state`, `w_next_state`, `unique casez` + `default`.
- Ready/Valid stable khi stalled; reset valid/control, không reset toàn RAM; use `$bits/$clog2` guarded width, avoid silent truncation and inferred latch.
- TB Verilator-friendly; **stimulus drive chỉ tại `posedge I_CLK`**. Sampling sau NBA có thể dùng `#1` trong TB khi cần; không dùng `#` trong RTL.

## G. Verification: phân biệt ĐÃ PASS vs CHƯA VERIFY

### G.1. Có log user xác nhận PASS

- Legacy single-bank `RECON_SUBSYSTEM_TOP`: **7/7 tests PASS, 121 checks, 168 recon beats, 589 cycles**, có H/V edges, commit, above-line, left boundary, above-left corner, availability guard.
- Standalone `CTU_RECON_EXPORT_TB`: **4/4 PASS**. TC1 8×8 / 24 beats / 72 cycles; TC2 32×16 / 192 beats / 1343 cycles; TC3 128×112 / 5376 beats / 33344 cycles; TC4 128×128 / 6144 beats / 18432 cycles. **Export đã bị bỏ khỏi active architecture**; các log này chỉ là bằng chứng đọc/raster độc lập.

### G.2. Lỗi/risks chưa đóng

- TB cũ nối `Recon Writer → CTU_RECON_LOCAL_RAM → CTU_RECON_EXPORT` **FAIL ở beat 0**: expected `0x00320027001c0011`, got `0x005e00530048003d` (actual dịch đúng 4 samples/1 word). Chưa có log chứng minh lỗi này đã fix; kiểm tra write address, read request→response latency và TB handshake/checker trước khi kết luận nguyên nhân.
- `RECON_DUAL_BANK_RTL_INTEGRATION.zip` mới có standalone TB/script; **chưa có HDL PASS log từ user cho phiên bản dual bank này**. `43/43` port static match trước đó không thay thế simulation/synthesis.
- Regression cũ `RECON_SUBSYSTEM_TOP` cần update theo port `I_FRAME_ID`, `I_CTU_ID`, Prefetch handshakes rồi chạy lại 7 tests.
- Trong Recon Top mới, single active CTU, Leaf partial CU có thể bị reject; 4K cuối hàng valid CTU height 112 cần confirm behavior của Partition/Intra/TQ cho mọi leaf và right/bottom boundaries.
- System-wide bandwidth, CABAC/syntax, normative SAO/ALF filter metadata, DBF CTU-boundary halo, and VVC conformance **chưa chứng nhận**.
- 200 MHz/4K30: chưa có end-to-end latency, P&R timing hoặc full-frame verification; một Leaf active có thể là performance bottleneck.

### G.3. Verification tối thiểu cho bước kế tiếp

1. `./tb/lint_recon_top.sh`, `./tb/run_verilator.sh` trong gói dual-bank (user WSL + Verilator).
2. Đảm bảo bank allocations CTU0/CTU1, FIFO descriptor stall, simultaneous write(B) + read(A), component Y/Cb/Cr readback, response latency 1cycle, early/invalid release blocked, wrong IDs rejected, global abort.
3. Tích hợp Prefetch + Input Buffer test: CTU8×8, 32×16, CTU128×112, CTU128×128; every word/metadata; full CTU count 6144; backpressure không làm mất response; test bank 0 prefetch vs bank 1 write.
4. Chạy lại Recon 7/7 regression và end-to-end `Intra → TQ → Recon → Prefetch` sample correctness, rồi mới claim completed.
5. Kiểm tra BRAM/URAM mapping, stall/time per CTU, line/halo storage, report timing ở 200 MHz.

## H. Những phần mới cần làm (theo thứ tự ưu tiên)

**P0 — Trước In-loop RTL:**
- User chạy Verilator dual-bank test và gửi log. Sửa lỗi nếu có; verify previous Recon readback FAIL is understood/resolved.
- Chốt giao thức `IN_LOOP_PREFETCH_CONTROLLER ↔ IN_LOOP_INPUT_BUFFER`: write ready/valid hoặc 1-beat/synchronous RAM write, reset/clear, valid width/height, lane masking, release semantics.
- Chốt ownership In-loop Input Buffer (EMPTY/FILLING/READY/FILTERING/FREE), CTU ID/Frame ID, điều kiện halo input safe.

**P1 — Thiết kế hai module mới:**
- `IN_LOOP_PREFETCH_CONTROLLER.sv`: nhận descriptor từ Recon Bank Ctrl, tạo raster addresses Y→Cb→Cr, target 1 word/cycle, tag response với component/addr đúng latency, write to Input Buffer, count accepted writes, release bank sau last write và drain.
- `IN_LOOP_INPUT_BUFFER.sv`: 1 CTU YUV420, 64-bit words, planes/address, separate write/read ports, filter-ready descriptor, input-buffer release.

**P2 — In-loop architecture:**
- Metadata: CU/TU boundary & QP source, DBF boundary strength and filter decisions, cross-CTU halo/line buffers.
- DBF sample scheduling/window/intermediate, then SAO, ALF with DBF→SAO→ALF dependencies; debug each stage on golden vectors.
- Preserve unfiltered Intra feedback; do not modify H/V Edge/Cross-CTU reference memories with filtered samples.

**P3 — System:**
- Global FSM CTU/Leaf Context, Original read owner transition, TU metadata/ID release, syntax+coeff to CABAC/bitstream, DDR4 filtered-frame writer, error recovery and frame completion.
- Verify 4K30/200 MHz with per-stage cycle counters (`T_E`, `T_P`, `T_F`) and actual synth utilization.

## I. Design contracts không được vô tình thay đổi

1. **Không** chuyển Leaf CU cho tới khi `CU_REF_COMMIT_DONE`, Intra CU done và CU resources release. In-loop filters **không** tham gia CU commit.
2. `CTU_RECON_DONE` thuộc Global FSM/CTU finish barrier, **không** đồng nghĩa last TU done.
3. Recon bank chỉ FREE sau matched Prefetch Release. Không đảo bank bằng `~bank_id` nếu chưa FREE.
4. **Bank Controller chỉ ownership/routing; Prefetch Controller mới tạo raster addresses.**
5. `RECON_RAM_RELEASE`, `INPUT_BUFFER_RELEASE`, `CTU_FILTER_DONE`, `FRAME_WRITE_DONE` là **bốn sự kiện khác nhau**.
6. Y/Cb/Cr samples unfiltered cho Intra, filtered cho frame-output. Không lấy ALF/SAO output quay lại Intra nội-frame.
7. `CTU_INPUT_ENGINE` original buffer release và Recon RAM bank release là **hai vòng đời độc lập**.
8. Không tự xem IP đơn lẻ PASS là whole encoder PASS. Những phần chưa có code/log phải ghi “đề xuất/chưa thực hiện”.

## J. Mẫu yêu cầu khi chuyển sang chat mới

Copy nội dung file `NEW_CHAT_START_PROMPT.txt`, upload handoff này cùng gói dual-bank RTL (có thể gửi luôn toàn bộ `VVC_ALL_INTRA_HANDOFF_BUNDLE.zip`). Trong chat mới, ưu tiên **đọc source thật**, sau đó quyết định tiếp tục ở P0 Verification hay P1 Prefetch; không tự thay kiến trúc đã chốt.

---

**Tóm tắt một dòng:** `Last CU Commit → CTU Finish → dual Recon RAM bank READY → external raster Prefetch vào 1×48 KiB Input Buffer → matched Bank Release → DBF→SAO→ALF → filtered frame`, trong khi Recon CU/CTU tiếp theo có thể chạy trên bank khác, với đúng dependency và ownership.
