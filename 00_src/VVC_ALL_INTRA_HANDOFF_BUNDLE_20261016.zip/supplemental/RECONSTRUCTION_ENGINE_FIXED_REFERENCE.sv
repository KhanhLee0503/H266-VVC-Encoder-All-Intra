//-----------------------------------------------------------
// Description: This module reconstructs one VVC transform unit at a time.
// It joins four signed inverse-transform residuals with a synchronous
// one-cycle final-prediction RAM response, adds the samples with explicit
// signed extension, clips the result to the pixel bit depth, and streams
// the samples to RECON_REF_STORE_WRITER in component-local CTU coordinates.
// The descriptor CU coordinates are ALREADY component-local, as emitted by
// ENCODER_TU_SCHEDULER. TU coordinates are CU-local offsets (zero in the
// baseline one-TU-per-component schedule). The design reserves storage for
// every issued RAM read using a two-entry reconstructed-output FIFO. It can
// accept one residual beat per cycle when the downstream remains ready.
// A missing/invalid one-cycle RAM response or invalid TU framing enters the
// sticky error state. I_CLEAR_ERROR synchronously aborts the active TU and
// must be coordinated with a flush of the connected datapath and memory.
//-----------------------------------------------------------
`timescale 1ns/1ps

module RECONSTRUCTION_ENGINE #(
  parameter integer PARA_PIXEL_WD  = 10,
  parameter integer PARA_SAMPLE_WD = 16,
  parameter integer PARA_TU_ID_WD  = 16,
  parameter integer PARA_CTU_ID_WD = 9,
  parameter integer PARA_CU_ID_WD  = 8,
  parameter integer PARA_COORD_WD  = 7
)(
  input                                  I_CLK,
  input                                  I_RESETN,
  input                                  I_CLEAR_ERROR,

  // Exactly one outstanding TU descriptor, one TU in flight.
  input                                  I_DESC_VALID,
  output logic                           O_DESC_READY,
  input  [PARA_TU_ID_WD-1:0]             I_DESC_TU_ID,
  input  [PARA_CTU_ID_WD-1:0]            I_DESC_CTU_ID,
  input  [PARA_CU_ID_WD-1:0]             I_DESC_CU_ID,
  input  [1:0]                           I_DESC_COMPONENT_ID,
  input  [PARA_COORD_WD-1:0]             I_DESC_CU_X,
  input  [PARA_COORD_WD-1:0]             I_DESC_CU_Y,
  input  [4:0]                           I_DESC_TU_X,
  input  [4:0]                           I_DESC_TU_Y,
  input  [1:0]                           I_DESC_WIDTH_SIZE,
  input  [1:0]                           I_DESC_HEIGHT_SIZE,

  // Row-major inverse residual, four signed 16-bit samples per beat.
  input                                  I_RES_VALID,
  output logic                           O_RES_READY,
  input  [4*PARA_SAMPLE_WD-1:0]          I_RES_DATA,
  input  [PARA_TU_ID_WD-1:0]             I_RES_TU_ID,
  input  [1:0]                           I_RES_COMPONENT,
  input                                  I_RES_TU_START,
  input                                  I_RES_TU_LAST,

  // One-cycle synchronous FINAL_PREDICTION_BUFFER read interface.
  output logic                           O_PRED_RD_REQ,
  output logic [1:0]                     O_PRED_RD_COMPONENT_ID,
  output logic [4:0]                     O_PRED_RD_X_BASE,
  output logic [4:0]                     O_PRED_RD_Y,
  input                                  I_PRED_RD_DATA_VALID,
  input  [4*PARA_SAMPLE_WD-1:0]          I_PRED_RD_DATA,
  input  [3:0]                           I_PRED_RD_LANE_VALID,

  // The output handshake and payload directly match the recon writer.
  output logic                           O_RECON_VALID,
  input                                  I_RECON_READY,
  output logic [1:0]                     O_RECON_COMPONENT_ID,
  output logic [6:0]                     O_RECON_X_BASE,
  output logic [6:0]                     O_RECON_Y,
  output logic [4*PARA_PIXEL_WD-1:0]     O_RECON_SAMPLE,
  output logic [3:0]                     O_RECON_LANE_VALID,
  output logic                           O_RECON_TU_LAST,

  output logic                           O_TU_DONE,
  output logic [PARA_TU_ID_WD-1:0]       O_DONE_TU_ID,
  output logic                           O_BUSY,
  output logic                           O_ERROR
);

  localparam logic [1:0] PARA_COMP_CR = 2'd2;
  localparam logic signed [PARA_SAMPLE_WD:0] PARA_PIXEL_MAX =
    ((PARA_SAMPLE_WD+1)'(1) << PARA_PIXEL_WD) - (PARA_SAMPLE_WD+1)'(1);

  typedef enum logic [1:0] {
    ST_IDLE,
    ST_ACTIVE,
    ST_ERROR
  } state_t;

  state_t r_current_state;
  state_t w_next_state;

  // A descriptor is not replaced until its final reconstructed beat retires.
  logic [PARA_TU_ID_WD-1:0] r_tu_id;
  logic [PARA_CTU_ID_WD-1:0] r_ctu_id;
  logic [PARA_CU_ID_WD-1:0] r_cu_id;
  logic [1:0] r_component_id;
  logic [6:0] r_cu_x_comp;
  logic [6:0] r_cu_y_comp;
  logic [4:0] r_tu_x;
  logic [4:0] r_tu_y;
  logic [1:0] r_width_size;
  logic [1:0] r_height_size;
  logic [9:0] r_beat_idx;
  logic       r_input_done;
  logic       r_error;
  logic       r_tu_done;
  logic [PARA_TU_ID_WD-1:0] r_done_tu_id;

  // One response is expected at the clock following an issued RAM request.
  logic       r_read_pending;
  logic [4*PARA_SAMPLE_WD-1:0] r_pending_residual;
  logic [6:0] r_pending_x;
  logic [6:0] r_pending_y;
  logic       r_pending_last;

  // Two entries absorb a response even if downstream stalls on that cycle.
  logic [4*PARA_PIXEL_WD-1:0] r_fifo_sample [0:1];
  logic [6:0] r_fifo_x [0:1];
  logic [6:0] r_fifo_y [0:1];
  logic       r_fifo_last [0:1];
  logic       r_fifo_head;
  logic       r_fifo_tail;
  logic [1:0] r_fifo_count;

  logic [5:0] w_desc_width;
  logic [5:0] w_desc_height;
  logic [8:0] w_desc_x_end;
  logic [8:0] w_desc_y_end;
  logic [6:0] w_desc_tu_x_end;
  logic [6:0] w_desc_tu_y_end;
  logic [7:0] w_comp_ctu_limit;
  logic       w_desc_ok;
  logic       w_desc_fire;

  logic [9:0] w_total_beats;
  logic [9:0] w_beat_row;
  logic [9:0] w_beat_column;
  logic [6:0] w_pred_x;
  logic [6:0] w_pred_y;
  logic [7:0] w_ctu_x;
  logic [7:0] w_ctu_y;
  logic       w_expected_last;
  logic       w_res_ok;
  logic       w_res_fire;
  logic       w_issue_credit;
  logic       w_res_fault;
  logic       w_response_fault;
  logic       w_unexpected_response;
  logic       w_fifo_push;
  logic       w_fifo_pop;
  logic       w_last_retired;
  logic [1:0] w_fifo_next_count;
  logic       w_pred_container_ok;
  logic signed [PARA_SAMPLE_WD:0] w_sum [0:3];
  logic [4*PARA_PIXEL_WD-1:0] w_clipped;

  // Descriptor validation uses component-space CTU bounds: 128 Y / 64 C.
  always_comb begin
    w_desc_width = 6'd4 << I_DESC_WIDTH_SIZE;
    w_desc_height = 6'd4 << I_DESC_HEIGHT_SIZE;
    w_comp_ctu_limit = (I_DESC_COMPONENT_ID == 2'd0) ? 8'd128 : 8'd64;
    w_desc_tu_x_end = {2'b00, I_DESC_TU_X} + {1'b0, w_desc_width};
    w_desc_tu_y_end = {2'b00, I_DESC_TU_Y} + {1'b0, w_desc_height};
    w_desc_x_end = {2'b00, I_DESC_CU_X} + {2'b00, I_DESC_TU_X}
                 + {3'b000, w_desc_width};
    w_desc_y_end = {2'b00, I_DESC_CU_Y} + {2'b00, I_DESC_TU_Y}
                 + {3'b000, w_desc_height};
    w_desc_ok = (I_DESC_COMPONENT_ID <= PARA_COMP_CR) &&
                (w_desc_tu_x_end <= 7'd32) &&
                (w_desc_tu_y_end <= 7'd32) &&
                (w_desc_x_end <= {1'b0, w_comp_ctu_limit}) &&
                (w_desc_y_end <= {1'b0, w_comp_ctu_limit}) &&
                (I_DESC_TU_X[1:0] == 2'b00) &&
                (I_DESC_TU_Y[1:0] == 2'b00) &&
                (I_DESC_CU_X[1:0] == 2'b00) &&
                (I_DESC_CU_Y[1:0] == 2'b00);
  end

  // Width size 0..3 denotes 1,2,4,8 four-sample beats per row.
  always_comb begin
    w_total_beats = 10'd4 << (r_width_size + {1'b0, r_height_size});
    w_beat_row = r_beat_idx >> r_width_size;
    w_beat_column = r_beat_idx & ((10'd1 << r_width_size) - 10'd1);
    w_pred_x = {2'b00, r_tu_x} + 7'(w_beat_column << 2);
    w_pred_y = {2'b00, r_tu_y} + 7'(w_beat_row);
    w_ctu_x = {1'b0, r_cu_x_comp} + {1'b0, w_pred_x};
    w_ctu_y = {1'b0, r_cu_y_comp} + {1'b0, w_pred_y};
    w_expected_last = (r_beat_idx == (w_total_beats - 10'd1));

    w_res_ok = (I_RES_TU_ID == r_tu_id) &&
               (I_RES_COMPONENT == r_component_id) &&
               (I_RES_TU_START == (r_beat_idx == 10'd0)) &&
               (I_RES_TU_LAST == w_expected_last) &&
               (w_pred_x <= 7'd28) && (w_pred_y <= 7'd31) &&
               (w_ctu_x <= ((r_component_id == 2'd0) ? 8'd124 : 8'd60)) &&
               (w_ctu_y <= ((r_component_id == 2'd0) ? 8'd127 : 8'd63));
  end

  // A request consumes a credit. Its response arrives one cycle later.
  // A new request is issued only if its future response is guaranteed room,
  // even when the recon consumer deasserts READY unexpectedly.
  assign O_RECON_VALID = (r_current_state == ST_ACTIVE) &&
                         (r_fifo_count != 2'd0) && !I_CLEAR_ERROR;
  assign O_RECON_COMPONENT_ID = r_component_id;
  assign O_RECON_X_BASE = r_fifo_x[r_fifo_head];
  assign O_RECON_Y = r_fifo_y[r_fifo_head];
  assign O_RECON_SAMPLE = r_fifo_sample[r_fifo_head];
  assign O_RECON_LANE_VALID = 4'b1111;
  assign O_RECON_TU_LAST = r_fifo_last[r_fifo_head];
  assign w_fifo_pop = O_RECON_VALID && I_RECON_READY;
  assign w_last_retired = w_fifo_pop && O_RECON_TU_LAST;

  always_comb begin
    w_pred_container_ok = 1'b1;
    for (int i = 0; i < 4; i++) begin
      if ((I_PRED_RD_DATA[i*PARA_SAMPLE_WD +: PARA_SAMPLE_WD] >> PARA_PIXEL_WD) != '0)
        w_pred_container_ok = 1'b0;
    end
  end

  assign w_response_fault = (r_current_state == ST_ACTIVE) && r_read_pending &&
                            (!I_PRED_RD_DATA_VALID ||
                             (I_PRED_RD_LANE_VALID != 4'b1111) ||
                             !w_pred_container_ok);
  assign w_unexpected_response = (r_current_state == ST_ACTIVE) &&
                                 I_PRED_RD_DATA_VALID && !r_read_pending;
  assign w_fifo_push = (r_current_state == ST_ACTIVE) && r_read_pending &&
                       !w_response_fault && !I_CLEAR_ERROR;
  assign w_fifo_next_count = r_fifo_count - {1'b0, w_fifo_pop} +
                             {1'b0, w_fifo_push};
  assign w_issue_credit = (w_fifo_next_count <= 2'd1);

  assign O_DESC_READY = (r_current_state == ST_IDLE) && !I_CLEAR_ERROR;
  assign w_desc_fire = I_DESC_VALID && O_DESC_READY;
  assign O_RES_READY = (r_current_state == ST_ACTIVE) && !r_input_done &&
                       !I_CLEAR_ERROR && !w_response_fault &&
                       !w_unexpected_response && w_issue_credit;
  assign w_res_fire = I_RES_VALID && O_RES_READY;
  assign w_res_fault = w_res_fire && !w_res_ok;

  assign O_PRED_RD_REQ = w_res_fire && w_res_ok;
  assign O_PRED_RD_COMPONENT_ID = r_component_id;
  assign O_PRED_RD_X_BASE = w_pred_x[4:0];
  assign O_PRED_RD_Y = w_pred_y[4:0];

  // Compute all four lane sums with 17-bit signed intermediates at default.
  always_comb begin
    w_clipped = '0;
    for (int i = 0; i < 4; i++) begin
      w_sum[i] = $signed({1'b0, I_PRED_RD_DATA[i*PARA_SAMPLE_WD +: PARA_SAMPLE_WD]}) +
                 $signed({r_pending_residual[(i+1)*PARA_SAMPLE_WD-1],
                          r_pending_residual[i*PARA_SAMPLE_WD +: PARA_SAMPLE_WD]});
      if (w_sum[i] < 0)
        w_clipped[i*PARA_PIXEL_WD +: PARA_PIXEL_WD] = '0;
      else if (w_sum[i] > PARA_PIXEL_MAX)
        w_clipped[i*PARA_PIXEL_WD +: PARA_PIXEL_WD] = {PARA_PIXEL_WD{1'b1}};
      else
        w_clipped[i*PARA_PIXEL_WD +: PARA_PIXEL_WD] = PARA_PIXEL_WD'(w_sum[i]);
    end
  end

  // Process 1: control FSM state register.
  always_ff @(posedge I_CLK or negedge I_RESETN) begin
    if (!I_RESETN)
      r_current_state <= ST_IDLE;
    else if (I_CLEAR_ERROR)
      r_current_state <= ST_IDLE;
    else
      r_current_state <= w_next_state;
  end

  // Process 2: control FSM transition logic.
  always_comb begin
    w_next_state = r_current_state;
    unique casez (r_current_state)
      ST_IDLE: begin
        if (w_desc_fire)
          w_next_state = w_desc_ok ? ST_ACTIVE : ST_ERROR;
      end
      ST_ACTIVE: begin
        if (w_res_fault || w_response_fault || w_unexpected_response)
          w_next_state = ST_ERROR;
        else if (w_last_retired)
          w_next_state = ST_IDLE;
      end
      ST_ERROR: begin
        w_next_state = ST_ERROR;
      end
      default: begin
        w_next_state = ST_ERROR;
      end
    endcase
  end

  // Descriptor and transient per-TU registers; no RAM payload reset needed.
  always_ff @(posedge I_CLK or negedge I_RESETN) begin
    if (!I_RESETN) begin
      r_tu_id <= '0;
      r_ctu_id <= '0;
      r_cu_id <= '0;
      r_component_id <= '0;
      r_cu_x_comp <= '0;
      r_cu_y_comp <= '0;
      r_tu_x <= '0;
      r_tu_y <= '0;
      r_width_size <= '0;
      r_height_size <= '0;
      r_beat_idx <= '0;
      r_input_done <= 1'b0;
      r_read_pending <= 1'b0;
      r_pending_residual <= '0;
      r_pending_x <= '0;
      r_pending_y <= '0;
      r_pending_last <= 1'b0;
      r_fifo_head <= 1'b0;
      r_fifo_tail <= 1'b0;
      r_fifo_count <= '0;
      r_error <= 1'b0;
      r_tu_done <= 1'b0;
      r_done_tu_id <= '0;
    end
    else if (I_CLEAR_ERROR) begin
      r_beat_idx <= '0;
      r_input_done <= 1'b0;
      r_read_pending <= 1'b0;
      r_fifo_head <= 1'b0;
      r_fifo_tail <= 1'b0;
      r_fifo_count <= '0;
      r_error <= 1'b0;
      r_tu_done <= 1'b0;
    end
    else begin
      r_tu_done <= 1'b0;
      if (w_desc_fire && !w_desc_ok)
        r_error <= 1'b1;
      if (w_res_fault || w_response_fault || w_unexpected_response)
        r_error <= 1'b1;

      if (w_desc_fire && w_desc_ok) begin
        r_tu_id <= I_DESC_TU_ID;
        r_ctu_id <= I_DESC_CTU_ID;
        r_cu_id <= I_DESC_CU_ID;
        r_component_id <= I_DESC_COMPONENT_ID;
        r_cu_x_comp <= 7'(I_DESC_CU_X);
        r_cu_y_comp <= 7'(I_DESC_CU_Y);
        r_tu_x <= I_DESC_TU_X;
        r_tu_y <= I_DESC_TU_Y;
        r_width_size <= I_DESC_WIDTH_SIZE;
        r_height_size <= I_DESC_HEIGHT_SIZE;
        r_beat_idx <= '0;
        r_input_done <= 1'b0;
      end

      if (r_current_state == ST_ACTIVE) begin
        r_read_pending <= w_res_fire && w_res_ok;
        if (w_res_fire && w_res_ok) begin
          r_pending_residual <= I_RES_DATA;
          r_pending_x <= w_ctu_x[6:0];
          r_pending_y <= w_ctu_y[6:0];
          r_pending_last <= I_RES_TU_LAST;
          if (w_expected_last)
            r_input_done <= 1'b1;
          else
            r_beat_idx <= r_beat_idx + 10'd1;
        end
        if (w_fifo_push) begin
          r_fifo_tail <= ~r_fifo_tail;
        end
        if (w_fifo_pop) begin
          r_fifo_head <= ~r_fifo_head;
        end
        unique casez ({w_fifo_push, w_fifo_pop})
          2'b10: r_fifo_count <= r_fifo_count + 2'd1;
          2'b01: r_fifo_count <= r_fifo_count - 2'd1;
          default: begin end
        endcase
        if (w_last_retired) begin
          r_tu_done <= 1'b1;
          r_done_tu_id <= r_tu_id;
        end
      end
      else begin
        r_read_pending <= 1'b0;
      end
    end
  end

  // The two-entry FIFO is written only when the expected RAM response arrives.
  always_ff @(posedge I_CLK) begin
    if (w_fifo_push) begin
      r_fifo_sample[r_fifo_tail] <= w_clipped;
      r_fifo_x[r_fifo_tail] <= r_pending_x;
      r_fifo_y[r_fifo_tail] <= r_pending_y;
      r_fifo_last[r_fifo_tail] <= r_pending_last;
    end
  end

  assign O_TU_DONE = r_tu_done;
  assign O_DONE_TU_ID = r_done_tu_id;
  assign O_BUSY = (r_current_state != ST_IDLE);
  assign O_ERROR = r_error;
endmodule: RECONSTRUCTION_ENGINE
