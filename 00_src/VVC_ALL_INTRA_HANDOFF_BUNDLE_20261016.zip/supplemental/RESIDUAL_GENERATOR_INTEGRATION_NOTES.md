# RESIDUAL_GENERATOR – integration contract (baseline, 2026-10-13)

Source: `RESIDUAL_GENERATOR(1).sv`; revised: `RESIDUAL_GENERATOR.sv`.

## New and changed ports

- `I_CLEAR_ERROR`: synchronous abort and error-clear input. No incoming CU/prediction/original request accepted during clear. **The external coordinator must flush Prediction Fork/TU Scheduler and drain CTU Original Read MUX before the next CU**, particularly if clear occurred with an Original RAM read outstanding.
- `I_CU_VALID_WIDTH[7:0]` / `I_CU_VALID_HEIGHT[7:0]`: valid luma coverage derived from `O_LEAF_NODE_DATA[36:29]` and `[28:21]` respectively. These are not coded block dimensions.
- Default `PARA_CTU_ID_WD=9`, `PARA_CU_ID_WD=8` (original: 16/16). `PARA_TU_ID_WD=16` unchanged.
- Existing output ports and Prediction Stream Fork input protocol retained.

## Geometry conversion from Partition

- `I_CU_X = {O_LEAF_X_UNIT,2'b00}`, `I_CU_Y = {O_LEAF_Y_UNIT,2'b00}`.
- `I_CU_WIDTH = 6'd4 << O_LEAF_WIDTH_CODE`, `I_CU_HEIGHT = 6'd4 << O_LEAF_HEIGHT_CODE`.
- `I_CU_VALID_WIDTH = O_LEAF_NODE_DATA[36:29]`, `I_CU_VALID_HEIGHT = O_LEAF_NODE_DATA[28:21]`.
- CTU Buffer ID comes from active CTU Context, not from Partition.

Accepted luma block sizes: rectangular 8/16/32 by 8/16/32, CTU-relative X/Y aligned to 4, fully inside 128x128 CTU. Chroma sizes are half of luma in 4:2:0. Local cache capacity for maximum 32x32 luma is 192 128-bit words. Corrected the parameterized row-padded allocation: PARA_MAX_CU=8/16/32 now allocates 16/48/192 words respectively (rather than underallocating chroma 4x4 for PARA_MAX_CU=8).

**Partial Leaf restriction:** `VALID_WIDTH/HEIGHT` must equal coded `WIDTH/HEIGHT`, or `O_ERROR` will assert and the module enters `ST_ERROR`. This is deliberately fail-closed: current Intra always outputs 4 valid lanes and there is no downstream partial-region masking contract. Supporting partial leaves requires a coordinated decision across Partition/Intra/TQ/Reconstruction. It is not sufficient to mask residuals in isolation.

## Handshake and sequence

1. Hold Leaf CU descriptor through `I_CU_VALID && O_CU_READY`.
2. Grant the Residual original-read client exclusive CTU Original MUX ownership until `O_PREFETCH_DONE` (all read responses captured).
3. Only then allow the Intra CU handshake and start the prediction stream.
4. For each component Y, Cb, Cr, accept complete row-major 4-sample beats; `TU_START` on the first beat only; `ROW_LAST` on the last beat of every row; `TU_LAST` on the last beat of the component; each component must retain its own TU_ID.
5. The sequence counters increment **only after `O_RES_VALID && I_RES_READY`**. Backpressure cannot skip a beat.
6. `O_CU_DONE` is held in `ST_DONE` until `I_RELEASE_CU`. Release only when dependent consumer/commit conditions are fulfilled.

## Verification status

- PASS: Python address/layout arithmetic property sweep across 7,225 legal CU geometries (including aligned and misaligned CTU RAM words); largest local usage 192 words and highest physical Y address 2047.
- PASS: static port-name matching with the existing `PREDICTION_STREAM_FORK.sv` (12 Prediction fields).
- NOT RUN: SystemVerilog compiler lint, synthesis, or simulation (no HDL compiler installed here).
- REQUIRED: HDL tests for chroma 4x4, irregular luma origins, downstream stalls, valid-size rejection, invalid TU framing, error recovery after an in-flight MUX response, and CTU boundary leaves.
