# RECONSTRUCTION_ENGINE — Integration and Verification Notes

## Baseline

- 200 MHz target; 10-bit unsigned reconstructed samples in four lanes per beat.
- One transform unit in flight, row-major inverse-transform output (4 × signed16).
- The TU descriptor is accepted with `I_DESC_VALID && O_DESC_READY`.
- `I_DESC_CU_X/Y` are **component-space CTU-local** coordinates, *not* luma coordinates for chroma. Do not divide these coordinates for Cb or Cr.
- `I_DESC_TU_X/Y` are **component-space CU-local** offsets (both zero for the one-TU-per-component baseline).
- Dimension codes `0/1/2/3` represent `4/8/16/32` samples.
- Full four-lane words and 4-aligned TU geometry are required. Partial CTU/leaf coding is not supported by this module version.

## Functional changes relative to RECONSTRUCTION_ENGINE(1).sv

1. Removed the second chroma coordinate divide-by-two.
2. Enforced descriptor bounds both within the 32×32 prediction buffer and within the 128×128 luma/64×64 chroma CTU.
3. Validated TU ID, component, TU_START and TU_LAST against beat count before issuing each prediction read.
4. Checked the next-clock prediction response for `DATA_VALID`, all four lane-valid bits, and zero upper bits above the pixel width; erroneous responses never enter the output FIFO.
5. Added sticky `ST_ERROR` and `I_CLEAR_ERROR` synchronous flush/recovery. Error recovery also requires flushing the upstream transform and downstream consumers before resuming; any stale synchronous RAM response must be drained/ignored.
6. Introduced a single pending synchronous read and a two-entry reconstructed-output FIFO. One beat/cycle is possible when input, prediction RAM, and downstream remain ready.
7. Preserved existing Writer output ports, including `O_TU_DONE` after the last reconstructed beat is **accepted**, not when reference availability updates are complete.

## Handshake details

A residual handshake (`I_RES_VALID && O_RES_READY`) issues exactly one synchronous prediction RAM request (`O_PRED_RD_REQ`). The RAM response must be presented on the following cycle (one-clock latency) with `I_PRED_RD_DATA_VALID=1`. The engine enqueues a reconstructed beat from that response. It reserves one free FIFO entry before issuing a new RAM request, so a subsequent downstream stall cannot drop a returned RAM response.

**Important:** `O_PRED_RD_REQ` has no request READY port. The final-prediction RAM must accept each asserted request and answer with the specified fixed latency. Predicted samples must have been written to the correct CU location before reads begin. A response arriving late is a protocol error; variable-latency memory requires a different read interface.

The output is held under stall (`O_RECON_VALID && !I_RECON_READY`). `I_CLEAR_ERROR` intentionally cancels any outstanding TU, including queued output, and must be driven as part of a coordinated pipeline abort.

## Required integration mappings

| Source | Destination |
| --- | --- |
| Scheduler `O_META_TU_ID`, `O_META_CTU_ID`, `O_META_CU_ID`, `O_META_COMPONENT_ID` | Recon `I_DESC_*` corresponding fields |
| Scheduler `O_META_CU_X/Y` | Recon `I_DESC_CU_X/Y` (no chroma scaling) |
| Scheduler `O_META_WIDTH_SIZE/HEIGHT_SIZE` | Recon `I_DESC_WIDTH_SIZE/HEIGHT_SIZE` |
| Baseline constant zero | Recon `I_DESC_TU_X/Y` |
| Inverse Transform `O_DATA_VALID/DATA/TU_ID/COMPONENT/TU_START/TU_LAST` | Recon residual input handshake/payload |
| Prediction Buffer `O_RD_DATA_VALID/DATA/LANE_VALID` | Recon `I_PRED_RD_*` inputs |
| Recon `O_RECON_*` | `RECON_REF_STORE_WRITER.I_RECON_*` corresponding inputs |
| Coordinated controller fault-clear | Recon `I_CLEAR_ERROR` |

## Validation performed

- Static port-name comparison against `RECON_REF_STORE_WRITER`: eight primary data/handshake port pairs present.
- A software model of the FIFO credit/ordering algorithm passed 480 randomized backpressure runs (4, 16, 32 and 256 beats, 120 seeds each).
- Signed clipping arithmetic sanity vectors passed.
- **No SystemVerilog compiler, lint run or RTL simulation was available in the current environment.** Synthesis timing/II=1 on hardware remain unverified.

## Minimum HDL tests still required

1. Y 4×4, 8×8, 16×16 and 32×32; check all output coordinates and last-beat pulse.
2. Cb/Cr with non-zero CTU-local component positions; verify coordinates are not halved again.
3. Prediction values 0/1023 and inverse residuals -32768/+32767; check 17-bit signed clip behavior.
4. Stalls at residual input, downstream writer and cycle of RAM response; scoreboard exact order and no duplicate.
5. Invalid descriptor: CTU overflow, local prediction-buffer overflow, misalignment and illegal component.
6. Invalid TU_ID/component/start/last, invalid or missing RAM response, nonzero prediction container upper bits.
7. Assert `I_CLEAR_ERROR` with pending RAM request/output queued, drain stale responses and verify restart with a new TU.

## Recon Subsystem readiness

The reconstruction arithmetic RTL is only one part of the feedback system. `RECON_SUBSYSTEM_TOP` has not been implemented/verified. It still needs writer-to-RAM integration; availability query arbitration; cross-CTU above-line, left-boundary and corner writes and bank lifecycle; per-CU Y/Cb/Cr commit barrier; and a defined CTU/row export path for DBF/SAO/ALF. These are blockers for claiming the **integrated Recon Subsystem** complete, although standalone In-loop Filter RTL architecture can be designed using a provisional unfiltered-reconstruction input contract.
