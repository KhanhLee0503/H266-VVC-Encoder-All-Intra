//-----------------------------------------------------------
// Description: This module classifies the texture activity of the
// current VVC coding-tree node as LOW, MEDIUM, or HIGH. The base
// activity metric is IDTV, calculated as the sum of the four
// accumulated directional variations. Threshold values are supplied
// by the partition control/configuration path so they can be tuned
// without changing this RTL. An optional variance numerator
// N*SUM_SQ-SUM*SUM can also participate in the classification.
// The variance hardware is removed at elaboration when disabled.
//-----------------------------------------------------------

`timescale 1ns/1ps

module PARTITION_ACTIVITY_CLASSIFIER
#(
  parameter PARA_SUM_WD       = 24,
  parameter PARA_SUM_SQ_WD    = 34,
  parameter PARA_DV_WD        = 23,
  parameter PARA_IDTV_WD      = 25,
  parameter PARA_VAR_WD       = 48,
  parameter PARA_USE_VARIANCE = 0
)
(
  input                              I_VALID,

  input      [PARA_SUM_WD-1:0]       I_SUM,
  input      [PARA_SUM_SQ_WD-1:0]    I_SUM_SQ,
  input      [PARA_DV_WD-1:0]        I_DV_H,
  input      [PARA_DV_WD-1:0]        I_DV_V,
  input      [PARA_DV_WD-1:0]        I_DV_DL,
  input      [PARA_DV_WD-1:0]        I_DV_DR,

  input      [2:0]                   I_WIDTH_CODE,
  input      [2:0]                   I_HEIGHT_CODE,

  input      [PARA_IDTV_WD-1:0]      I_IDTV_LOW_THRESHOLD,
  input      [PARA_IDTV_WD-1:0]      I_IDTV_HIGH_THRESHOLD,

  input      [PARA_VAR_WD-1:0]       I_VAR_LOW_THRESHOLD,
  input      [PARA_VAR_WD-1:0]       I_VAR_HIGH_THRESHOLD,

  output logic                       O_VALID,
  output logic [1:0]                 O_ACTIVITY,
  output logic                       O_ACTIVITY_LOW,
  output logic                       O_ACTIVITY_MEDIUM,
  output logic                       O_ACTIVITY_HIGH,

  output logic [PARA_IDTV_WD-1:0]    O_IDTV,
  output logic [PARA_VAR_WD-1:0]     O_VAR_NUM
);

localparam PARA_ACTIVITY_LOW    = 2'd0;
localparam PARA_ACTIVITY_MEDIUM = 2'd1;
localparam PARA_ACTIVITY_HIGH   = 2'd2;

logic [PARA_DV_WD:0]      w_idtv_pair_0;
logic [PARA_DV_WD:0]      w_idtv_pair_1;
logic [PARA_IDTV_WD-1:0]  w_idtv;

logic                     w_low_idtv;
logic                     w_high_idtv;

logic [PARA_VAR_WD-1:0]   w_var_num;
logic                     w_low_var;
logic                     w_high_var;

logic                     w_activity_low;
logic                     w_activity_high;

// IDTV is the sum of the four accumulated directional variations.
// The pairwise adder structure limits the combinational adder depth.
assign w_idtv_pair_0 =
  {1'b0, I_DV_H} +
  {1'b0, I_DV_V};

assign w_idtv_pair_1 =
  {1'b0, I_DV_DL} +
  {1'b0, I_DV_DR};

assign w_idtv =
  PARA_IDTV_WD'(w_idtv_pair_0) +
  PARA_IDTV_WD'(w_idtv_pair_1);

// Low and high IDTV comparisons are evaluated in parallel.
assign w_low_idtv =
  (w_idtv <= I_IDTV_LOW_THRESHOLD);

assign w_high_idtv =
  (w_idtv >= I_IDTV_HIGH_THRESHOLD);

// The optional variance path is generated only when the project
// configuration enables it. The node width and height are powers
// of two, so N*SUM_SQ is implemented as a left shift rather than
// a general multiplication.
generate
  if (PARA_USE_VARIANCE == 1) begin: GEN_VARIANCE
    logic [4:0]                 w_area_shift;
    logic [PARA_VAR_WD-1:0]     w_sum_sq_scaled;
    logic [PARA_VAR_WD-1:0]     w_sum_squared;

    assign w_area_shift =
      {2'b00, I_WIDTH_CODE} +
      {2'b00, I_HEIGHT_CODE} +
      5'd4;

    assign w_sum_sq_scaled =
      PARA_VAR_WD'(I_SUM_SQ) << w_area_shift;

    assign w_sum_squared =
      PARA_VAR_WD'(I_SUM) *
      PARA_VAR_WD'(I_SUM);

    assign w_var_num =
      (w_sum_sq_scaled >= w_sum_squared) ?
      (w_sum_sq_scaled - w_sum_squared) :
      {PARA_VAR_WD{1'b0}};

    assign w_low_var =
      (w_var_num <= I_VAR_LOW_THRESHOLD);

    assign w_high_var =
      (w_var_num >= I_VAR_HIGH_THRESHOLD);
  end
  else begin: GEN_NO_VARIANCE
    assign w_var_num  = {PARA_VAR_WD{1'b0}};
    assign w_low_var  = 1'b1;
    assign w_high_var = 1'b0;
  end
endgenerate

// LOW requires low IDTV and, when enabled, low variance. HIGH is
// asserted by high IDTV or high variance. MEDIUM is the remaining
// range. HIGH has priority if threshold programming causes overlap.
assign w_activity_low =
  w_low_idtv &&
  w_low_var;

assign w_activity_high =
  w_high_idtv ||
  w_high_var;

// The classifier is purely combinational. I_VALID qualifies all
// externally visible classification outputs.
always_comb begin
  O_VALID           = I_VALID;
  O_ACTIVITY        = PARA_ACTIVITY_MEDIUM;
  O_ACTIVITY_LOW    = 1'b0;
  O_ACTIVITY_MEDIUM = 1'b0;
  O_ACTIVITY_HIGH   = 1'b0;

  if (I_VALID) begin
    if (w_activity_high) begin
      O_ACTIVITY      = PARA_ACTIVITY_HIGH;
      O_ACTIVITY_HIGH = 1'b1;
    end
    else if (w_activity_low) begin
      O_ACTIVITY     = PARA_ACTIVITY_LOW;
      O_ACTIVITY_LOW = 1'b1;
    end
    else begin
      O_ACTIVITY        = PARA_ACTIVITY_MEDIUM;
      O_ACTIVITY_MEDIUM = 1'b1;
    end
  end
end

assign O_IDTV    = w_idtv;
assign O_VAR_NUM = w_var_num;

endmodule: PARTITION_ACTIVITY_CLASSIFIER
